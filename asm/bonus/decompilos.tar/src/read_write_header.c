/*
** EPITECH PROJECT, 2019
** asm
** File description:
** read_header
*/

#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <endian.h>
#include <string.h>
#include <stdio.h>
#include "my.h"
#include "op.h"

size_t prog_len;

static char *get_dest_name(const char *filepath)
{
    size_t len = strlen(filepath);
    char *dest = malloc(sizeof(char) * (len - 1));

    if (!dest)
        return NULL;
    strncpy(dest, filepath, len - 3);
    dest[len - 3] = 's';
    dest[len - 2] = '\0';
    return dest;
}

static void write_header(header_t *header, int fd)
{
    dprintf(fd, ".name \"%s\"\n", header->prog_name);
    dprintf(fd, ".comment \"%s\"\n\n", header->comment);
}

char *read_header(const char *filepath, int *fd)
{
    char *dest = get_dest_name(filepath);
    char *str;
    header_t header;
    ssize_t n_read;
    int size;

    if (!dest)
        return NULL;
    n_read = read(*fd, &header, sizeof(header_t));
    if (n_read != sizeof(header_t))
        return NULL;
    if (be32toh(header.magic) != COREWAR_EXEC_MAGIC)
        return NULL;
    size = be32toh(header.prog_size);
    str = malloc(sizeof(char) * (size + 1));
    if (!str)
        return close(*fd), free(dest), NULL;
    if (read(*fd, str, size) != size)
        return close(*fd), free(dest), free(str), NULL;
    str[size] = '\0';
    prog_len = size;
    close(*fd);
    *fd = open(dest, O_CREAT | O_TRUNC | O_WRONLY, 0664);
    free(dest);
    if (*fd == -1)
        return NULL;
    return write_header(&header, *fd), str;
}
