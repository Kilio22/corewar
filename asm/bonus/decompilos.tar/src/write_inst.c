/*
** EPITECH PROJECT, 2019
** asm
** File description:
** write_inst
*/

#include <stdio.h>
#include <stdbool.h>
#include "op.h"

#define ARG_TYPE(n) (((desc << n * 2) & 0b11000000) >> 6)
int get_arg_length(char type, int index);
bool op_needs_args(int op_idx);

enum instruction_types {
    REG = 1,
    DIR,
    IDR
};

static int read_arg(char *bytecode, int offset, int n)
{
    int arg = bytecode[offset] & 0b10000000 ? -1 : 0;

    for (int i = 0; i < n; i++) {
        arg <<= 8;
        arg |= bytecode[offset] & 0b11111111;
        offset = (offset + 1) % MEM_SIZE;
    }
    return arg;
}

static int get_arg(char *bytecode, char type, int op_idx, int *offset)
{
    int arg_len = get_arg_length(type, op_idx);
    int arg = read_arg(bytecode, *offset, arg_len);

    *offset = (*offset + arg_len) % MEM_SIZE;
    return arg;
}

static void get_inst_arguments(char *bytecode, int arg[4], int op_idx, code_t code)
{
    char type = 0;
    int offset = 2;

    if (!op_needs_args(op_idx)) {
        --offset;
        arg[0] = get_arg(bytecode, op_idx == OP_LIVE ? 0b10 : 0b11, op_idx, &offset);
        return;
    }
    for (int i = 0; i < op_tab[op_idx].nbr_args; i++) {
        type = (code & 0b11000000) >> 6;
        arg[i] = get_arg(bytecode, type, op_idx, &offset);
        code <<= 2;
    }
}

int write_inst(char *bytecode, int op_idx, code_t desc, int fd)
{
    int args[4];

    get_inst_arguments(bytecode, args, op_idx, desc);
    dprintf(fd, "%s ", op_tab[op_idx].mnemonique);
    for (int i = 0; i < op_tab[op_idx].nbr_args; i++) {
        if (!op_needs_args(op_idx) || ARG_TYPE(i) == DIR)
            dprintf(fd, "%%");
        else if (ARG_TYPE(i) == REG)
            dprintf(fd, "r");
        dprintf(fd, "%d", args[i]);
        if (i < op_tab[op_idx].nbr_args - 1)
            dprintf(fd, ", ");
    }
    dprintf(fd, "\n");
    return 0;
}
