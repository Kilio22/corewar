/*
** EPITECH PROJECT, 2018
** main.c
** File description:
** Main function
*/

#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <endian.h>
#include <stdio.h>
#include "my.h"
#include "op.h"

char *read_header(const char *filepath, int *fd);
int analyse_bytecode(char *bytecode, int fd);

int main(int argc, char *argv[])
{
    int fd;
    char *bytecode;

    if (argc != 2)
        return 84;
    if (!my_str_ends_with(argv[1], ".cor"))
        return 84;
    fd = open(argv[1], O_RDONLY);
    if (fd == -1)
        return 84;
    bytecode = read_header(argv[1], &fd);
    if (!bytecode || fd == -1)
        return 84;
    return analyse_bytecode(bytecode, fd);
}
