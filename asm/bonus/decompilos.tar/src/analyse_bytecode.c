/*
** EPITECH PROJECT, 2019
** asm
** File description:
** write_bytecode
*/

#include <endian.h>
#include <stdio.h>
#include <stdlib.h>
#include <ncurses.h>
#include <unistd.h>
#include <string.h>
#include <stdbool.h>
#include "op.h"

int write_inst(char *bytecode, int op_idx, code_t desc, int fd);
int count_inst_bytes(code_t code, int op_idx);
int check_param_bytecode(int op_idx, char args);
extern size_t prog_len;

bool op_needs_args(int index)
{
    if (index == 0 || index == 11 || index == 14)
        return false;
    if (index == 8 || (index >= 17 && index <= 27))
        return false;
    return true;
}

static code_t get_param_code(char *bytecode, int op_idx)
{
    if (!op_needs_args(op_idx))
        return 0;
    return bytecode[1];
}

static bool is_instruction_valid(char *bytecode, int op_idx)
{
    if (op_idx < 0 || op_idx > (OP_NB - 2))
        return false;
    if (!op_needs_args(op_idx))
        return true;
    if (check_param_bytecode(op_idx, bytecode[1]) == -1)
        return false;
    return true;
}

int analyse_bytecode(char *bytecode, int fd)
{
    size_t i = 0;
    int op_idx;
    code_t code;

    while (i < prog_len) {
        op_idx = bytecode[i] - 1;
        if (!is_instruction_valid(bytecode + i, op_idx)) {
            dprintf(fd, "# invalid bytecode / instruction\n");
            ++i;
            continue;
        }
        code = get_param_code(bytecode + i, op_idx);
        if (write_inst(bytecode + i, op_idx, code, fd) == -1) {
            dprintf(fd, "# invalid bytecode / instruction\n");
            ++i;
        } else
            i += count_inst_bytes(code, op_idx);
    }
    return 0;
}
