/*
** EPITECH PROJECT, 2019
** CPE_corewar_2018
** File description:
** corewar
*/

#ifndef COREWAR_H_
#define COREWAR_H_

extern const char *whitespace_chars;

#endif /* !COREWAR_H_ */
