/*
** EPITECH PROJECT, 2019
** CPE_corewar_2018
** File description:
** op
*/

#include "op.h"

const op_t op_tab[] = {
    {"live", 1, {T_DIR}, 1, 10},
    {"ld", 2, {T_DIR | T_IND, T_REG}, 2, 5},
    {"st", 2, {T_REG, T_IND | T_REG}, 3, 5},
    {"add", 3, {T_REG, T_REG, T_REG}, 4, 10},
    {"sub", 3, {T_REG, T_REG, T_REG}, 5, 10},
    {"and", 3, {T_REG | T_DIR | T_IND, T_REG | T_IND | T_DIR, T_REG}, 6, 6},
    {"or", 3, {T_REG | T_IND | T_DIR, T_REG | T_IND | T_DIR, T_REG}, 7, 6},
    {"xor", 3, {T_REG | T_IND | T_DIR, T_REG | T_IND | T_DIR, T_REG}, 8, 6},
    {"zjmp", 1, {T_DIR}, 9, 20},
    {"ldi", 3, {T_REG | T_DIR | T_IND, T_DIR | T_REG, T_REG}, 10, 25},
    {"sti", 3, {T_REG, T_REG | T_DIR | T_IND, T_DIR | T_REG}, 11, 25},
    {"fork", 1, {T_DIR}, 12, 800},
    {"lld", 2, {T_DIR | T_IND, T_REG}, 13, 10},
    {"lldi", 3, {T_REG | T_DIR | T_IND, T_DIR | T_REG, T_REG}, 14, 50},
    {"lfork", 1, {T_DIR}, 15, 1000},
    {"aff", 1, {T_REG}, 16, 2},
    {"cmp", 2, {T_REG | T_IND, T_REG | T_DIR | T_IND}, 17, 12},
    {"nzjmp", 1, {T_DIR}, 18, 20},
    {"ejmp", 1, {T_DIR}, 19, 20},
    {"nejmp", 1, {T_DIR}, 20, 20},
    {"nlejmp", 1, {T_DIR}, 21, 20},
    {"nljmp", 1, {T_DIR}, 22, 20},
    {"gjmp", 1, {T_DIR}, 23, 20},
    {"gejmp", 1, {T_DIR}, 24, 20},
    {"ngejmp", 1, {T_DIR}, 25, 20},
    {"ngjmp", 1, {T_DIR}, 26, 20},
    {"ljmp", 1, {T_DIR}, 27, 20},
    {"lejmp", 1, {T_DIR}, 28, 20},
    {"push", 1, {T_REG | T_DIR | T_IND}, 29, 7},
    {"pop", 1, {T_REG | T_IND}, 30, 7},
    {0, 0, {0}, 0, 0}
};
