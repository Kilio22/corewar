/*
** EPITECH PROJECT, 2019
** CPE_corewar_2018
** File description:
** globals
*/

#include "corewar.h"

const char *whitespace_chars = " \t";
