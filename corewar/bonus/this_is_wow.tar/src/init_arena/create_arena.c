/*
** EPITECH PROJECT, 2019
** corewar
** File description:
** create_arena
*/

#include <unistd.h>
#include <stdlib.h>
#include "corewar.h"

static int put_bytecode_at_adress(arena_t *arena,
int size, champion_t *champ, int id)
{
    char buf[size + 1];
    char *ptr = buf;
    ssize_t n_read = read(champ->fd, buf, size);

    if (n_read != size)
        return -1;
    for (int i = champ->pc; size--; i++) {
        if (i >= MEM_SIZE)
            i %= MEM_SIZE;
        arena[i].c = *ptr++;
        arena[i].id = id;
    }
    return 0;
}

arena_t *create_arena(champion_t **champions)
{
    arena_t *arena = malloc(sizeof(arena_t) * MEM_SIZE);
    int n_return;

    if (!arena)
        return NULL;
    for (int i = 0; i < MEM_SIZE; i++) {
        arena[i].c = '\0';
        arena[i].id = 0;
    }
    for (int i = 0; champions[i]; i++) {
        n_return = put_bytecode_at_adress(arena,
champions[i]->prog_size, champions[i], champions[i]->prog_id);
        if (n_return == -1) {
            free(arena);
            return NULL;
        }
    }
    return arena;
}
