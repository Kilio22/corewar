/*
** EPITECH PROJECT, 2019
** corewar
** File description:
** screen_print_utils
*/

#include <stdlib.h>
#include "corewar.h"

int find_champ_pc(int index, core_t *core)
{
    for (int i = 0; core->champions[i]; i++) {
        if (core->champions[i]->pc == index)
            return 1;
    }
    return -1;
}

int check_process(core_t *core, int id)
{
    int nb_find = 0;

    for (int i = 0; core->champions[i]; i++) {
        if (core->champions[i]->prog_id == id)
            nb_find++;
    }
    return nb_find > 0 ? nb_find - 1 : 0;
}

static void reinit_case(core_t *core, int id)
{
    for (int i = 0; i < MEM_SIZE; i++) {
        if (core->arena[i].id == id)
            core->arena[i].id = 200;
    }
}

void update_champions_save(core_t *core)
{
    int index = 0;

    for (int i = 0; core->save_ch[i]; i++) {
        index = find_champion_index(core, core->save_ch[i]->prog_id);
        if (get_champion_live(core->save_ch[i]->prog_id) == -1)
            reinit_case(core, core->save_ch[i]->prog_id);
        if (index == -1)
            continue;
        core->save_ch[i]->pc = core->champions[index]->pc;
        core->save_ch[i]->last_cmd = core->champions[index]->last_cmd;
    }
}