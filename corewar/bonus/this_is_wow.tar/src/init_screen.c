/*
** EPITECH PROJECT, 2019
** corewar
** File description:
** screen_managment
*/

#include <ncurses.h>
#include <stdlib.h>
#include "corewar.h"

static void init_colors(void)
{
    init_pair(1, COLOR_BLUE, 0);
    init_pair(5, COLOR_BLUE, COLOR_WHITE);
    init_pair(2, COLOR_RED, 0);
    init_pair(6, COLOR_RED, COLOR_WHITE);
    init_pair(3, COLOR_GREEN, 0);
    init_pair(7, COLOR_GREEN, COLOR_WHITE);
    init_pair(4, COLOR_CYAN, 0);
    init_pair(8, COLOR_CYAN, COLOR_WHITE);
    init_pair(200, 245, 0);
}

static int init_save_champ(core_t *core)
{
    int len = my_arraylen((void **) core->champions);
    int i = 0;

    core->save_ch = malloc(sizeof(champion_t *) * (len + 1));
    if (!core->save_ch)
        return 84;
    for (; i < len; i++) {
        core->save_ch[i] = malloc(sizeof(champion_t));
        if (!core->save_ch[i])
            return 84;
        my_strcpy(core->save_ch[i]->prog_name, core->champions[i]->prog_name);
        core->save_ch[i]->prog_id = core->champions[i]->prog_id;
        core->save_ch[i]->pc = core->champions[i]->pc;
        core->save_ch[i]->forked = false;
        core->save_ch[i]->last_cmd = NULL;
        core->champions[i]->last_cmd = NULL;
    }
    core->save_ch[i] = NULL;
    return 0;
}

int init_screen(core_t *core)
{
    start_color();
    core->game_board = subwin(stdscr, 13, 220, 64, 0);
    wborder(core->game_board, '|', '|', '-', '-', '/', '\\', '\\', '/');
    wrefresh(core->game_board);
    if (init_save_champ(core) == 84)
        return 84;
    init_colors();
    clear();
    refresh();
    return 0;
}