/*
** EPITECH PROJECT, 2019
** CPE_corewar_2018
** File description:
** op
*/

#include "corewar.h"
#include "instructions.h"

const op_t op_tab[] = {
    {"live", 1, {T_DIR}, 1, 10, inst_live},
    {"ld", 2, {T_DIR | T_IND, T_REG}, 2, 5, inst_ld},
    {"st", 2, {T_REG, T_IND | T_REG}, 3, 5, inst_st},
    {"add", 3, {T_REG, T_REG, T_REG}, 4, 10, inst_add},
    {"sub", 3, {T_REG, T_REG, T_REG}, 5, 10, inst_sub},
    {"and", 3, {T_REG | T_DIR | T_IND, T_REG | T_IND | T_DIR, T_REG}, 6, 6,
inst_and},
    {"or", 3, {T_REG | T_IND | T_DIR, T_REG | T_IND | T_DIR, T_REG}, 7, 6,
inst_or},
    {"xor", 3, {T_REG | T_IND | T_DIR, T_REG | T_IND | T_DIR, T_REG}, 8, 6,
inst_xor},
    {"zjmp", 1, {T_DIR}, 9, 20, inst_zjmp},
    {"ldi", 3, {T_REG | T_DIR | T_IND, T_DIR | T_REG, T_REG}, 10, 25, inst_ldi},
    {"sti", 3, {T_REG, T_REG | T_DIR | T_IND, T_DIR | T_REG}, 11, 25, inst_sti},
    {"fork", 1, {T_DIR}, 12, 800, inst_fork},
    {"lld", 2, {T_DIR | T_IND, T_REG}, 13, 10, inst_lld},
    {"lldi", 3, {T_REG | T_DIR | T_IND, T_DIR | T_REG, T_REG}, 14, 50,
inst_lldi},
    {"lfork", 1, {T_DIR}, 15, 1000, inst_lfork},
    {"aff", 1, {T_REG}, 16, 2, inst_aff},
    {"cmp", 2, {T_REG | T_IND, T_REG | T_DIR | T_IND}, 17, 12, inst_cmp},
    {"nzjmp", 1, {T_DIR}, 18, 20, inst_nzjmp},
    {"ejmp", 1, {T_DIR}, 19, 20, inst_ejmp},
    {"nejmp", 1, {T_DIR}, 20, 20, inst_nejmp},
    {"nlejmp", 1, {T_DIR}, 21, 20, inst_nlejmp},
    {"nljmp", 1, {T_DIR}, 22, 20, inst_nljmp},
    {"gjmp", 1, {T_DIR}, 23, 20, inst_gjmp},
    {"gejmp", 1, {T_DIR}, 24, 20, inst_gejmp},
    {"ngejmp", 1, {T_DIR}, 25, 20, inst_ngejmp},
    {"ngjmp", 1, {T_DIR}, 26, 20, inst_ngjmp},
    {"ljmp", 1, {T_DIR}, 27, 20, inst_ljmp},
    {"lejmp", 1, {T_DIR}, 28, 20, inst_lejmp},
    {"push", 1, {T_REG | T_DIR | T_IND}, 29, 7, inst_push},
    {"pop", 1, {T_REG | T_IND}, 30, 7, inst_pop},
    {0, 0, {0}, 0, 0, 0}
};
