/*
** EPITECH PROJECT, 2019
** corewar
** File description:
** menu
*/

#include <ncurses.h>
#include <stdlib.h>
#include <fcntl.h>
#include "corewar.h"

const char *authors[] = {
    "Kylian BALAN, Nathan BELLANGER, Nathan LECORCHET"
};

static int print_too_little_term(void)
{
    if (COLS < 317 || LINES < 77) {
        clear();
        mvprintw(LINES / 2, COLS / 2 - 8, "ENLARGE/DEZOOM YOUR TERMINAL");
        refresh();
        return 1;
    }
    return 0;
}

static void print_menu(int highlight, char ***logo)
{
    int y = 10;
    static int color = 1;

    if (print_too_little_term() == 1)
        return;
    for (int i = 0; logo[0][i]; i++, y++) {
        attron(COLOR_PAIR(color));
        mvprintw(y, (COLS / 2) - 73, logo[0][i]);
        attroff(COLOR_PAIR(color));
        color += color < 200 ? 1 : -200;
    }
    y += 10;
    for (int i = 0; i < 2; i++) {
        if (i == highlight)
            attron(COLOR_PAIR(209));
        for (int j = 0; logo[i + 1][j]; j++, y++)
                mvprintw(y, COLS / 2 - 23, logo[i + 1][j]);
        attroff(COLOR_PAIR(209));
    }
}

int menu(void)
{
    int highlight = 0;
    char key = 0;
    char ***logo = get_logo();

    if (!logo)
        return 84;
    init_ncurses();
    while (42) {
        clear();
        print_menu(highlight, logo);
        mvprintw(LINES - 1, (COLS / 2) - 24, authors[0]);
        refresh();
        key = getch();
        if (key == 'A' && highlight > 0)
            highlight--;
        if (key == 'B' && highlight < 1)
            highlight++;
        if (key == 10)
            break;
    }
    for (int i = 0; i < 3; i++)
        my_free_fields(logo[i]);
    free(logo);
    return highlight;
}