/*
** EPITECH PROJECT, 2019
** corewar
** File description:
** screen_print
*/

#include <stdlib.h>
#include <ncurses.h>
#include "corewar.h"

const char *titles[] = {
    "Name:",
    "Cycle until death:",
    "Nb process:",
    "Last instruction:"
};

static void get_values(core_t *core, char **values, int i)
{
    int nb_live = 0;

    values[0] = core->save_ch[i]->prog_name;
    nb_live = get_champion_live(core->save_ch[i]->prog_id);
    values[1] = my_itoa(nb_live);
    nb_live = 1 + check_process(core, core->save_ch[i]->prog_id);
    get_champion_live(core->save_ch[i]->prog_id) == -1 ? nb_live = 0 : 0;
    values[2] = my_itoa(nb_live);
    values[3] = core->save_ch[i]->last_cmd;
}

static void print_value(char **values, int tab_coord[2], core_t *core, int i)
{
    mvwprintw(core->game_board, tab_coord[1], tab_coord[0], titles[i]);
    if (values[i]) {
        tab_coord[0] += my_strlen(titles[i]);
        mvwprintw(core->game_board, tab_coord[1], tab_coord[0], values[i]);
        tab_coord[0] -= my_strlen(titles[i]);
    }
    tab_coord[1] += 2;
    if (i == 1 || i == 2)
        free(values[i]);
    values[i] = NULL;
}

static void print_scoreboard(core_t *core)
{
    int tab_coord[2] = {1, 1};
    char *values[4];

    for (int i = 0; core->save_ch[i]; i++) {
        get_values(core, values, i);
        if (get_champion_live(core->save_ch[i]->prog_id) == -1)
            wattron(core->game_board, COLOR_PAIR(200));
        else
            wattron(core->game_board, COLOR_PAIR(core->save_ch[i]->prog_id));
        for (int i = 0; i < 4; i++)
            print_value(values, tab_coord, core, i);
        if (get_champion_live(core->save_ch[i]->prog_id) == -1)
            wattroff(core->game_board, COLOR_PAIR(200));
        else
            wattroff(core->game_board, COLOR_PAIR(core->save_ch[i]->prog_id));
        tab_coord[0] += 50;
        tab_coord[1] = 1;
    }
}

static int print_arena_memory(arena_t *ptr, int tab[2], int total, core_t *core)
{
    int tab_coord[2] = {tab[0], tab[1]};
    char *str;

    for (int i = 0; i < 96; i++) {
        str = char_to_hexstr(ptr[i].c);
        if (!str)
            return -1;
        tab_coord[0]++;
        find_champ_pc(i + total, core) == 1 ?
attron(COLOR_PAIR(ptr[i].id + 4)) : attron(COLOR_PAIR(ptr[i].id));
        mvprintw(tab_coord[1], tab_coord[0], "%s", str);
        find_champ_pc(i + total, core) == 1 ?
attroff(COLOR_PAIR(ptr[i].id + 4)) : attroff(COLOR_PAIR(ptr[i].id));
        tab_coord[0] += 2;
        free(str);
    }
    return 0;
}

void print_arena(core_t *core, arena_t *arena)
{
    char *str;
    int tab_coord[2] = {0, 0};
    static int nb_cycles = 0;

    nb_cycles++;
    if (nb_cycles != 15)
        return;
    nb_cycles = 0;
    clear();
    wborder(core->game_board, '|', '|', '-', '-', '/', '\\', '\\', '/');
    for (int i = 0; i < MEM_SIZE; i += 96) {
        str = int_to_hexstr(i);
        if (!str)
            return;
        mvprintw(tab_coord[1], 0, str);
        for (tab_coord[0] = my_strlen(str); tab_coord[0] < 5; tab_coord[0]++);
        mvprintw(tab_coord[1], tab_coord[0], ":");
        free(str);
        tab_coord[0]++;
        if (print_arena_memory(arena + i, tab_coord, i, core) == -1)
            return;
        tab_coord[1]++;
    }
    print_scoreboard(core);
    wrefresh(core->game_board);
    refresh();
}