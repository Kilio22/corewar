/*
** EPITECH PROJECT, 2019
** corewar
** File description:
** inst_pop
*/

#include <sys/resource.h>
#include <stdlib.h>
#include "corewar.h"
#include "instructions.h"

static int check_stack(my_stack_t *stack)
{
    size_t i = 0;
    struct rlimit old;

    for (; stack; i++)
        stack = stack->next;
    getrlimit(RLIMIT_STACK, &old);
    if (i >= old.rlim_max)
        return -1;
    return 0;
}

int inst_pop(champion_t *champ, core_t *core UNU, code_t desc, int *args)
{
    int pos;
    my_stack_t *new_head;

    if (is_reg(desc, args, 1) == -1)
        return -1;
    if (!champ->stack || check_stack(champ->stack) == -1)
        return 0;
    pos = (champ->pc + (GET_VAL(0) % IDX_MOD)) % MEM_SIZE;
    while (pos < 0)
        pos += MEM_SIZE;
    if (ARG_TYPE(0) == REG)
        champ->reg[args[0] - 1] = champ->stack->value;
    else
        write_arg(core, pos, champ->stack->value, champ->prog_id);
    new_head = champ->stack->next;
    free(champ->stack);
    champ->stack = new_head;
    return 0;
}
