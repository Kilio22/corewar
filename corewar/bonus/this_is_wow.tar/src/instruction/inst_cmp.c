/*
** EPITECH PROJECT, 2019
** corewar
** File description:
** inst_cmp
*/

#include "corewar.h"
#include "instructions.h"

int inst_cmp(champion_t *champ, core_t *core, code_t desc, int *args)
{
    if (is_reg(desc, args, 2) == -1)
        return -1;
    champ->carry = GET_VAL(0) - GET_VAL(1);
    return 0;
}
