/*
** EPITECH PROJECT, 2019
** corewar
** File description:
** inst_ljmp
*/

#include "corewar.h"
#include "instructions.h"

int inst_ljmp(champion_t *champ, core_t *core UNU, code_t desc UNU, int *args)
{
    if (champ->carry >= 0)
        return 0;
    champ->pc = (champ->pc + (args[0] % IDX_MOD) - 3) % MEM_SIZE;
    while (champ->pc < 0)
        champ->pc += MEM_SIZE;
    return 0;
}
