/*
** EPITECH PROJECT, 2019
** corewar
** File description:
** inst_push
*/

#include <stdlib.h>
#include "corewar.h"
#include "instructions.h"

static int push_to_stack(int value, champion_t *champ)
{
    my_stack_t *new = malloc(sizeof(my_stack_t));

    if (!new)
        return -1;
    new->value = value;
    new->next = champ->stack;
    champ->stack = new;
    return 0;
}

int inst_push(champion_t *champ, core_t *core UNU, code_t desc, int *args)
{
    if (is_reg(desc, args, 1) == -1)
        return -1;
    if (push_to_stack(GET_VAL(0), champ) == -1)
        return -1;
    return 0;
}
