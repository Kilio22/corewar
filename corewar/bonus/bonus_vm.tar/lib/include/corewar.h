/*
** EPITECH PROJECT, 2019
** corewar
** File description:
** corewar
*/

#ifndef COREWAR_H_
#define COREWAR_H_

#include <stdbool.h>
#include <stdio.h>
#include <ncurses.h>
#include "op.h"
#include "my.h"
#include "my_stdio.h"
#include "my_string.h"
#include "parsing.h"
#include "champions.h"

typedef struct champion champion_t;

typedef struct arena_s {
    char c;
    int id;
} arena_t;

typedef struct core_s {
    WINDOW *game_board;
    WINDOW *score_board;
    champion_t **champions;
    champion_t **save_ch;
    arena_t *arena;
} core_t;

void print_params(parsing_t *parsing);
void print_champions(champion_t **champions);
arena_t *create_arena(champion_t **champions);
int loop_corewar(core_t *core, int dump);
void print_arena(core_t *core, arena_t *arena);
void display_winning_champions(champion_t **champions);
bool is_game_ended(champion_t **champions);
void update_champions_live_status(champion_t **champions);
bool op_needs_args(int op_idx);
void get_inst_arguments(arena_t *arena, int arg[4], int op_idx, int pc);
int check_param_bytecode(int op_idx, char args);
int find_type(char args);
int count_inst_bytes(code_t code, int op_idx);
int get_arg_length(char type, int index);
int read_arg(arena_t *arena, int offset, int n);
void write_arg(core_t *core, int offset, int val, int id);
int find_champion_index(core_t *core, int nb);
int check_process(core_t *core, int id);
int find_champ_pc(int index, core_t *core);
char *char_to_hexstr(char nbr);
char *int_to_hexstr(int nbr);
int init_screen(core_t *core);
void update_champions_save(core_t *core);
int menu(void);
char *get_line(FILE *f_stream);
char ***get_logo(void);
void init_ncurses(void);

int debug(champion_t *champ, core_t *core, code_t desc, int *args);

#endif /* !COREWAR_H_ */
