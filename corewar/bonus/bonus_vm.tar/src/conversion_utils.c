/*
** EPITECH PROJECT, 2019
** corewar
** File description:
** conversion_utils
*/

#include "corewar.h"

char *char_to_hexstr(char nbr)
{
    char *base = "0123456789ABCDEF";
    int base_length = 16;
    int r;
    unsigned char result = nbr;
    char str[3] = {'0', '0', 0};

    for (int i = 0; result != 0; i++) {
        r = result % base_length;
        result = result / base_length;
        str[i] = base[r];
    }
    return (my_strdup(my_revstr(str)));
}

char *int_to_hexstr(int nbr)
{
    char *base = "0123456789ABCDEF";
    int base_length = 16;
    int r;
    unsigned int result;
    char str[50] = "";

    if (nbr < 0)
        result = 4294967296 + nbr;
    else
        result = nbr;
    if (nbr == 0)
        str[0] = '0';
    for (int i = 0; result != 0; i++) {
        r = result % base_length;
        result = result / base_length;
        str[i] = base[r];
    }
    return (my_strdup(my_revstr(str)));
}