/*
** EPITECH PROJECT, 2019
** corewar
** File description:
** get_first_two_bytes
*/

int get_first_two_bytes(int val)
{
    return val >> 16;
}