/*
** EPITECH PROJECT, 2019
** corewar
** File description:
** inst_lld
*/

#include "corewar.h"
#include "instructions.h"

int inst_lld(champion_t *champ, core_t *core, code_t desc, int *args)
{
    if (is_reg(desc, args, 2) == -1)
        return -1;
    champ->reg[args[1] - 1] = GET_LVAL(0);
    refresh_carry(champ, champ->reg[args[1] - 1]);
    return 0;
}
