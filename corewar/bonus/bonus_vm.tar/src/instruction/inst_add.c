/*
** EPITECH PROJECT, 2019
** inst_add.c
** File description:
** add intruction
*/

#include "corewar.h"
#include "instructions.h"

int inst_add(champion_t *champ, core_t *core, code_t desc, int *args)
{
    if (is_reg(desc, args, 3) == -1)
        return -1;
    champ->reg[args[2] - 1] = GET_VAL(0) + GET_VAL(1);
    refresh_carry(champ, champ->reg[args[2] - 1]);
    return 0;
}
