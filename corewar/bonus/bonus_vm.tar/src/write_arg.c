/*
** EPITECH PROJECT, 2019
** corewar
** File description:
** write_arg
*/

#include <endian.h>
#include <ncurses.h>
#include <unistd.h>
#include "corewar.h"

void write_arg(core_t *core, int offset, int val, int id)
{
    char byte;

    val = htobe32(val);
    for (int i = 0; i < 4; i++) {
        byte = val & 0b11111111;
        val >>= 8;
        core->arena[offset].c = byte;
        core->arena[offset].id = id;
        offset = (offset + 1) % MEM_SIZE;
    }
/*     print_arena(core, core->arena);
    refresh();
    usleep(400000);
 */}
